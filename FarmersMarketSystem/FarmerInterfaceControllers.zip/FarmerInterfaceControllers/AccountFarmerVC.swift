//
//  AccountFarmerVC.swift
//  FarmersMarketSystem
//
//  Created by Asset on 11/18/24.
//

import UIKit

class AccountFarmerVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .systemCyan
    }
}
